#!/bin/bash

clear

echo `rm q1_output.txt`

clear

while read var1
do

var2=${#var1}

var3=${var1:0:4}

for (( val=4; val<=$var2-1; val++ ))
do
	var3=$var3'#'
done

echo $var3 >> "q1_output.txt"

done < "$1"


clear



