#!/bin/bash


# The age is calculated based on date 14-06-2021
clear

declare -i age

echo `rm q2_output.txt`

clear

Date=$(date +%m/%d/%Y)

day=${Date:3:2}
month=${Date:0:2}
year=${Date:6:4}

declare -i yd
declare -i md
declare -i ad



while read  l;
do
       
	   len=${#l}

	   w=${l:len-10:10}

            d=${w:0:2}
	    m=${w:3:2}
	    y=${w:6:4}

	    
	

	    yd=$(echo "$year-$y" | bc )
	    md=$(echo "$month-$m" | bc )
	    dd=$(echo "$day-$d" | bc )

	     	if test $md = 0
		then 
			if test $dd -ge 0
			then
		            age=$yd
		else
			age=$((yd-1))
			fi
		fi

		if test $md -lt 0
		then
			age=$((yd-1))
		
		fi

		if test $md -gt 0
		then
			age=$yd
		fi

		

		word=${l:0:len-11}

		echo $word  $age>>"q2_output.txt"


	done < "$1"
	clear
