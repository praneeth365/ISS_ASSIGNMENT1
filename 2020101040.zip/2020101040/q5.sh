#!/bin/bash

clear

echo `rm final.txt output.txt temp.txt temp2.txt temp3.txt temp4.txt`

if [ $# -eq 0 ]
then

echo "Directories:" > "final.txt"

echo `find . -type d` | tr " " "\n" > "output.txt"

 while read line
 do
	 for word in $line
	 do
		 if [ $word != "." ]
		 then

    var=$(find "$word" -type f | wc -l)
    line=$line" "$var"file(s)"
    echo "$line" >> "temp.txt"
		 fi

done
  done < "output.txt"

echo `sort -k2 -nr "temp.txt" | tee "output.txt"`

echo `tr -s '[:blank:]' ',' < output.txt | tee "output.txt"`

echo `cat output.txt >> final.txt`

echo >> "final.txt"

echo "Files:" >> "final.txt"

echo 

echo `find . -type f` | tr " " "\n"  > "temp2.txt"

while read line
do
	for word in $line
	do
		var=$(wc -c $word)
		line=$line" $var"
		echo "$line" >> "temp3.txt"
	done
done < "temp2.txt"

echo `sort -k2 -nr "temp3.txt" | tee "temp2.txt"`

echo `awk '{print $1}' temp2.txt > temp4.txt`

echo `cat temp4.txt >> final.txt`

clear

echo "$(<final.txt)"
else
	string=$1
	len=${#string}
	if [ ${string:len-1:1} -ne "/" ]
	then
		string=$string"/"
	fi

	echo "Directories:" > "final.txt"

echo `find $string -type d` | tr " " "\n" > "output.txt"

 while read line
 do
	 for word in $line
	 do
		 if [ $word != "." ]
		 then

    var=$(find "$word" -type f | wc -l)
    line=$line" "$var"file(s)"
    echo "$line" >> "temp.txt"
		 fi

done
  done < "output.txt"

echo `sort -k2 -nr "temp.txt" | tee "output.txt"`

echo `tr -s '[:blank:]' ',' < output.txt | tee "output.txt"`

echo `cat output.txt >> final.txt`

echo >> "final.txt"

echo "Files:" >> "final.txt"

echo 

echo `find $string -type f` | tr " " "\n"  > "temp2.txt"

while read line
do
	for word in $line
	do
		var=$(wc -c $word)
		line=$line" $var"
		echo "$line" >> "temp3.txt"
	done
done < "temp2.txt"

echo `sort -k2 -nr "temp3.txt" | tee "temp2.txt"`

echo `awk '{print $1}' temp2.txt > temp4.txt`

echo `cat temp4.txt >> final.txt`

clear

echo "$(<final.txt)"


fi
