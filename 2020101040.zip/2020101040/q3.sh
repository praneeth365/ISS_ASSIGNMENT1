#!/bin/bash

clear


echo "Words - start with ‘s’ and is not follow by ‘a’"

while read line
do
	for word in $line
	do
		if [ ${word:0:1} == "s" ] && [ ${word:1:1} != "a" ]
               then
		       echo $word
		fi
	done
done <"$1"

echo "Word starts with ‘w’ and is followed by ‘h’"

while read line
do
	for word in $line
	do
		if [ ${word:0:1} == "w" ] && [ ${word:1:1} == "h" ]
		then
		echo $word
		fi
	done
done <"$1"

echo "Word starts with ‘t’ and is followed by ‘h’"

while read line
do
	for word in $line
	do
		if [ ${word:0:1} == "t" ] && [ ${word:1:1} == "h" ]
		then
			echo $word
		fi
	done
done <"$1"

echo "Word starts with ‘a’ and is not followed by ‘n’" 

while read line
do
        for word in $line
        do
                if [ ${word:0:1} == "a" ] && [ ${word:1:1} != "n" ]
                then
                        echo $word
                fi
        done
done <"$1"


