#!/bin/bash

echo `rm output.txt`

clear

while read line
do
	echo `sed -i "s/\b$line\b//g" "$1"`

done < "$2"

echo `sed -i 's/ \+/ /g' "$1"`

while read line
do
	cnt1=0
	cnt2=0
	for word in $line
	do
		if [ $3 == $word ]
		then
			cnt1=$((cnt1+1))
		fi

		if [ $word != "," ] && [ $word != "?" ] && [ $word != "!" ] && [ $word != "." ] && [ $word != ";" ]
		then
			cnt2=$((cnt2+1))
		fi
	done

	echo -n  "$line," >> "Output.txt"
	echo  "$cnt1 / $cnt2" | bc -l >> "Output.txt"

done < "$1"

clear
