#!/bin/bash


clear


echo `rm temp.txt temp2.txt`

clear

if [ $1 == "-C" ]
then
op=$2

elif [ $2 == "-C" ]
then
op=$3

elif [ $3 == "-C" ]
then
op=$4

elif [ $4 == "-C" ]
then
op=$5

elif [ $5 == "-C" ]
then
op=$6

elif [ $6 == "-C" ]
then
op=$7

elif [ $7 == "-C" ]
then
op=$8

elif [ $8 == "-C" ]
then
op=$9

elif [ $9 == "-C" ]
then
op=${10}

elif [ ${10} == "-C" ]
then
op=${11}

elif [ ${11} == "-C" ]
then
op=${12}
fi





	if [ $op == "insert" ]
	then
                  case $1 in 
          "-f")
                  firstname=$2 ;;
          "-l")
	          lastname=$2 ;;
	  "-n")
		  contactno=$2 ;;
	  "-o")
		  company=$2 ;;
            esac

              case $3 in 
          "-f")
                  firstname=$4 ;;
          "-l")
	          lastname=$4 ;;
	  "-n")
		  contactno=$4 ;;
	  "-o")
		  company=$4 ;;
            esac

            case $5 in
           "-f")
                  firstname=$6 ;;
          "-l")
                  lastname=$6 ;;
          "-n")
                  contactno=$6 ;;
          "-o")
                  company=$6 ;;

	  esac

	  case $7 in
	  "-f")
                  firstname=$8 ;;
          "-l")
                  lastname=$8 ;;
          "-n")
                  contactno=$8 ;;
          "-o")
                  company=$8 ;;

          esac

	   case $9 in
          "-f")
                  firstname=${10} ;;
          "-l")
                  lastname=${10} ;;
          "-n")
                  contactno=${10} ;;
          "-o")
                  company=${10} ;;


          esac

	  echo "$firstname,$lastname,$contactno,$company" >> "contacts.csv"
	  echo "$firstname $lastname $contactno $comapny" >> "space.txt"

	fi
        
	if [ $op == "display" ]
	then
                 if [ $1 == "-a" ]
		then
			echo `sort -k1 -t, "contacts.csv"` >> "temp.txt"
                      
			while read line
			do
				for word in $line
				do
					echo $word
				done
			done < "temp.txt"
		fi

		if [ $1 == "-d" ]
		then
			echo `sort -r -k1 -t, "contacts.csv"` >> "temp2.txt"

			  while read line
                        do
                                for word in $line
                                do
                                        echo $word
                                done
                        done < "temp2.txt"
		fi

                if [ $2 == "-a" ]
		then
			echo `sort -k1 -t, "contacts.csv"` >> "temp.txt"
                      
			while read line
			do
				for word in $line
				do
					echo $word
				done
			done < "temp.txt"
		fi

		if [ $2 == "-d" ]
		then
			echo `sort -r -k1 -t, "contacts.csv"` >> "temp2.txt"

			  while read line
                        do
                                for word in $line
                                do
                                        echo $word
                                done
                        done < "temp2.txt"
		fi
                if [ $3 == "-a" ]
		then
			echo `sort -k1 -t, "contacts.csv"` >> "temp.txt"
                      
			while read line
			do
				for word in $line
				do
					echo $word
				done
			done < "temp.txt"
		fi

		if [ $3 == "-d" ]
		then
			echo `sort -r -k1 -t, "contacts.csv"` >> "temp2.txt"

			  while read line
                        do
                                for word in $line
                                do
                                        echo $word
                                done
                        done < "temp2.txt"
		fi
		if [ $3 == "-a" ]
		then
			echo `sort -k1 -t, "contacts.csv"` >> "temp.txt"
                      
			while read line
			do
				for word in $line
				do
					echo $word
				done
			done < "temp.txt"
		fi

		if [ $3 == "-d" ]
		then
			echo `sort -r -k1 -t, "contacts.csv"` >> "temp2.txt"

			  while read line
                        do
                                for word in $line
                                do
                                        echo $word
                                done
                        done < "temp2.txt"
		fi
	fi

	if [ $op == "edit" ]
		then
         case $1 in
	  "-k")
		  editedname=$2 ;;
          "-f")
                  firstname=$2 ;;
          "-l")
                  lastname=$2 ;;
          "-n")
                  contactno=$2 ;;
          "-o")
                  company=$2 ;;
            esac

	    case $3 in
	  "-k")
		  editedname=$4 ;;
          "-f")
                  firstname=$4 ;;
          "-l")
                  lastname=$4 ;;
          "-n")
                  contactno=$4 ;;
          "-o")
                  company=$4 ;;
            esac

	       case $5 in
          "-k")
                  editedname=$6 ;;
          "-f")
                  firstname=$6 ;;
          "-l")
                  lastname=$6 ;;
          "-n")
                  contactno=$6 ;;
          "-o")
                  company=$6 ;;
            esac

	         case $7 in
          "-k")
                  editedname=$8 ;;
          "-f")
                  firstname=$8 ;;
          "-l")
                  lastname=$8 ;;
          "-n")
                  contactno=$8 ;;
          "-o")
                  company=$8 ;;
            esac

	          case $9 in
          "-k")
                  editedname=${10} ;;
          "-f")
                  firstname=${10} ;;
          "-l")
                  lastname=${10} ;;
          "-n")
                  contactno=${10} ;;
          "-o")
                  company=${10} ;;
            esac

	    case ${11} in
          "-k")
                  editedname=${12} ;;
          "-f")
                  firstname=${12} ;;
          "-l")
                  lastname=${12} ;;
          "-n")
                  contactno=${12} ;;
          "-o")
                  company=${12} ;;
            esac
           
	           line=$editedname
                   num=$(awk -v myvar="$line" -F , '{  if ( $1 == myvar ) print NR }' contacts.csv)
		   num=$num"s"
                   num="$num/.*/$firstname,$lastname,$contactno,$company/"
                   echo `sed -i "$num" contacts.csv`
	fi


    if [ $op == "search" ]
    then

            if [ $1 == "-c" ]
	    then
		    if [ $2 == "fname" ]
		    then
			    if [ $3 == "-v" ]
                            then
                                line=$4
                                else
                                line=$6
                                fi 

			    echo `awk -v myvar="$line" -F , '{if ($1 == myvar) print $0}' contacts.csv`
		    fi

		    if [ $2 == "lname" ]
		    then
                    if [ $3 == "-v" ]
                            then
                                line=$4
                                else
                                line=$6
                                fi 
			    echo `awk -v myvar="$line" -F , '{if ($2 == myvar) print $0}' contacts.csv`
		    fi

		    if [ $2 == "mobile" ]
		    then
                    if [ $3 == "-v" ]
                            then
                                line=$4
                                else
                                line=$6
                                fi 
			    echo `awk -v myvar="$line" -F , '{if ($3 == myvar) print $0}' contacts.csv`
		    fi

		     if [ $2 == "office" ]
                    then
                    if [ $3 == "-v" ]
                            then
                                line=$4
                                else
                                line=$6
                                fi 
                            echo `awk -v myvar="$line" -F , '{if ($4 == myvar) print $0}' contacts.csv`
                    fi
	    fi

	    if [ $3 == "-c" ]
	    then
		    if [ $4 == "fname" ]
                    then
                            if [ $1 == "-v" ]
                            then
                                line=$2
                                else
                                line=$6
                                fi 
                            echo `awk -v myvar="$line" -F , '{if ($1 == myvar) print $0}' contacts.csv`
                    fi

                    if [ $4 == "lname" ]
                    then
                            if [ $1 == "-v" ]
                            then
                                line=$2
                                else
                                line=$6
                                fi 
                            echo `awk -v myvar="$line" -F , '{if ($2 == myvar) print $0}' contacts.csv`
                    fi

                    if [ $4 == "mobile" ]
                    then
                            if [ $1 == "-v" ]
                            then
                                line=$2
                                else
                                line=$6
                                fi 
                            echo `awk -v myvar="$line" -F , '{if ($3 == myvar) print $0}' contacts.csv`
                    fi

                     if [ $4 == "office" ]
                    then
                            if [ $1 == "-v" ]
                            then
                                line=$2
                                else
                                line=$6
                                fi 
                            echo `awk -v myvar="$line" -F , '{if ($4 == myvar) print $0}' contacts.csv`
                    fi
	    fi

             if [ $5 == "-c" ]
	    then
		    if [ $6 == "fname" ]
                    then
                            if [ $1 == "-v" ]
                            then
                                line=$2
                                else
                                line=$4
                                fi 
                            echo `awk -v myvar="$line" -F , '{if ($1 == myvar) print $0}' contacts.csv`
                    fi

                    if [ $6 == "lname" ]
                    then
                            if [ $1 == "-v" ]
                            then
                                line=$2
                                else
                                line=$4
                                fi 
                            echo `awk -v myvar="$line" -F , '{if ($2 == myvar) print $0}' contacts.csv`
                    fi

                    if [ $6 == "mobile" ]
                    then
                            if [ $1 == "-v" ]
                            then
                                line=$2
                                else
                                line=$4
                                fi 
                            echo `awk -v myvar="$line" -F , '{if ($3 == myvar) print $0}' contacts.csv`
                    fi

                     if [ $6 == "office" ]
                    then
                            if [ $1 == "-v" ]
                            then
                                line=$2
                                else
                                line=$4
                                fi 
                            echo `awk -v myvar="$line" -F , '{if ($4 == myvar) print $0}' contacts.csv`
                    fi
	    fi
		    
    fi

    if [ $op == "delete" ]
    then
	    if [ $1 == "-c" ]
	    then
            if [ $2 == "fname" ]
            then
                   if [ $3 == "-v" ]
                   then
                   line=$4
                   else
                   line=$6
                   fi
	           num=$(awk -v myvar="$line" -F , '{  if ( $1 == myvar ) print NR }' contacts.csv)
	           num="$num""d"
	           echo `sed -i "$num" contacts.csv`
		    
	    fi

	    if [ $2 == "lname" ]
            then
                   if [ $3 == "-v" ]
                   then
                   line=$4
                   else
                   line=$6
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $2 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`
             fi

            if [ $2 == "mobile" ]
            then
                   if [ $3 == "-v" ]
                   then
                   line=$4
                   else
                   line=$6
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $3 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`
            fi

            if [ $2 == "office" ]
             then
                   if [ $3 == "-v" ]
                   then
                   line=$4
                   else
                   line=$6
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $4 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`
            fi
	    fi
   
	    if [ $3 == "-c" ]
	    then

		    if [ $4 == "fname" ]
            then
                     if [ $1 == "-v" ]
                   then
                   line=$2
                   else
                   line=$6
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $1 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`

            fi

            if [ $4 == "lname" ]
            then
                     if [ $1 == "-v" ]
                   then
                   line=$2
                   else
                   line=$6
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $2 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`
             fi

            if [ $4 == "mobile" ]
            then
                     if [ $1 == "-v" ]
                   then
                   line=$2
                   else
                   line=$6
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $3 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`
            fi

            if [ $4 == "office" ]
             then
                     if [ $1 == "-v" ]
                   then
                   line=$2
                   else
                   line=$6
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $4 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`
            fi
            fi

            if [ $5 == "-c" ]
	    then

		    if [ $6 == "fname" ]
            then
                     if [ $1 == "-v" ]
                   then
                   line=$2
                   else
                   line=$4
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $1 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`

            fi

            if [ $6 == "lname" ]
            then
                     if [ $1 == "-v" ]
                   then
                   line=$2
                   else
                   line=$4
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $2 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`
             fi

            if [ $6 == "mobile" ]
            then
                     if [ $1 == "-v" ]
                   then
                   line=$2
                   else
                   line=$4
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $3 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`
            fi

            if [ $6 == "office" ]
             then
                     if [ $1 == "-v" ]
                   then
                   line=$2
                   else
                   line=$4
                   fi
                   num=$(awk -v myvar="$line" -F , '{  if ( $4 == myvar ) print NR }' contacts.csv)
                   num="$num""d"
                   echo `sed -i "$num" contacts.csv`
            fi
            fi


    fi

